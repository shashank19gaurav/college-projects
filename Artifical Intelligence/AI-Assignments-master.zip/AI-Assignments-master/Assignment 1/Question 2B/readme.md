Simulation for the following problem - 

Implement a simple reflex agent for the vacuum environment in Q.2A. Run
the environment with this agent for all possible initial dirt configurations and agent locations. Record the performance score of each configuration and overall average score.
import MyAss1.Agent;
import MyAss1.World;

class Simulate {
    public  static void main(String args[]){
        double rxValue, ryValue;
        int rRow, rColumn;
        double averagePerformance = 0.0;

        for (int j =0 ; j<5 ; j++) {
            //Taking average 5 times 
            //For different configuration

            rxValue = Math.random();
            ryValue = Math.random();

            rRow = (int) Math.floor(rxValue * 10);
            rColumn = (int) Math.floor(ryValue * 10);

            //World is 2x2 by matrix
            Agent agent = new Agent(rRow, rColumn, 10 , 10);
            World world = new World(10, 10);

            world.intcWorld();
            int currentMeasure = 0;

            for (int i = 0; i < 50; i++ ) {
                if (world.cWorld[agent.getRow()][agent.getColumn()] == 0) {
                    currentMeasure+=world.getPerformanceMeasure();
                    System.out.println(i + " block saaf hai!");
                } else {
                    System.out.println(i + " block ganda hai!");
                }
                //System.out.println("Current Position X :"+ agent.getRow() + " Y : "+ agent.getColumn());


                //Deciding the next move based on the current scenario
                agent.move();
            }
            System.out.println("Current Agent Perfomance Score : " + currentMeasure);
            averagePerformance += currentMeasure;
        }

        System.out.println("Average Perfomance :" + (averagePerformance/5));

       
    }
} 
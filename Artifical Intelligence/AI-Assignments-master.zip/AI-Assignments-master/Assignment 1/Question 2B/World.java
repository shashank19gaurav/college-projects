package MyAss1;

public class World {

    int wRow, wCol;
    public int cWorld[][];
    int performanceMeasure;

    double x;

    public static void main(String[] args) {
        World w = new World(10, 10);
        w.intcWorld();
        w.printcWorld();
        
    }

    public World(int wRow, int wCol) {
        this.wCol = wCol;
        this.wRow = wRow;
        cWorld = new int[wRow][wCol];
        performanceMeasure = 0;
    }

    public int randcWorld() {
        x = Math.random();
        if (x <= 0.5) {
            return 0;
        } else {
            return 1;
        }
    }

    public void intcWorld() {
        for (int i = 0; i < this.wRow; i++) {
            for (int j = 0; j < this.wCol; j++) {
                cWorld[i][j] = randcWorld();
                if(cWorld[i][j] == 0) {
                    performanceMeasure++;
                }
            }
        }
    }

    public void printcWorld() {
        for (int i = 0; i < this.wRow; i++) {
            for (int j = 0; j < this.wCol; j++) {
                System.out.println(cWorld[i][j]);
            }
        }
    }

    public int getPerformanceMeasure(){
        return performanceMeasure;
    }

}

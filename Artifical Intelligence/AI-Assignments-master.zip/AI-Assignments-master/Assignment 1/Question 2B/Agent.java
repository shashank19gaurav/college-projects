package MyAss1;

public class Agent {

    public static void main(String args[]) {

    }//main

    int cRow, cCol, wRow, wCol;
    double x;

    public Agent(int cRow, int cCol, int wRow, int wCol) {
        this.cCol = cCol;
        this.cRow = cRow;
        this.wCol = wCol;
        this.wRow = wRow;
    }

    public void mDown() {
        if (cRow < wRow-1) {
            cRow++;
        }
    }

    public void mUp() {
        if (cRow > 0) {
            cRow--;
        }
    }

    public void mLeft() {
        if (cCol > 0) {
            cCol--;
        }
    }

    public void mRight() {
        if (cCol < wCol-1) {
            cCol++;
        }
    }

    public int getRow() {
        return cRow;
    }

    public int getColumn() {
        return cCol;
    }

   public void move() {

        if (this.cRow == 0 && this.cCol == 0) {
            // Agent is at Top Left Corner
            // You can move right or down
            // Selecting randomly from them
            x = Math.random();
            if (x <= 0.5) {
                mDown();
            } else {
                mRight();
            }

        } else if (this.cRow == 0 && this.cCol == this.wCol - 1) {
            // Top Right corner
            // Can move left or down
            x = Math.random();
            if (x <= 0.5) {
                mDown();
            } else {
                mLeft();
            }
        } else if (this.cRow == wRow - 1 && this.cCol == 0) {
            // Bottom left
            //can move up or right
            x = Math.random();
            if (x <= 0.5) {
                mUp();
            } else {
                mRight();
            }

        } else if (this.cRow == this.wRow - 1 && this.cCol == this.wCol - 1) {
            // Bottom Right
            // Can move up or left
            x = Math.random();
            if (x <= 0.5) {
                mUp();
            } else {
                mLeft();
            }
        } else {
            x = Math.random();
            if (x <= 0.25) {
                 mUp();
            } else if (x <= 0.5) {
                mLeft();
            } else if (x <= 0.75 ) {
                mDown();
            } else 
                mRight();
        }
    }//move

}//classAgent

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Movie_Database
{
    public partial class Form7 : Form
    {
        public Form7(string movie_name)
        {
            InitializeComponent();
            DBConnect db = new DBConnect();
            db.OpenConnection();

            MySqlConnection connection = db.getConnection();
            MySqlCommand command = connection.CreateCommand();
            string query = "SELECT * FROM movie LEFT OUTER JOIN director ON movie.director_id = director.id WHERE movie.title LIKE '%"+ movie_name +"%';";
            command.CommandText = query;
           // MessageBox.Show(query);
           //command.ExecuteReader();
           using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    label6.Text = reader.GetString(reader.GetOrdinal("title"));
                    label7.Text = reader.GetString(reader.GetOrdinal("name"));
                    label8.Text = reader.GetString(reader.GetOrdinal("genre"));

                    string imagelink = "D:/C++ Programs(While Learning)/Movie Database/images/movies/" + reader.GetString(reader.GetOrdinal("image"));

                    pictureBox1.Image = Image.FromFile(imagelink);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox1.Size = new Size(276, 206);

                }
            }
           query = String.Format("SELECT name, review, rating FROM (movie LEFT OUTER JOIN users_movies ON movie.id = users_movies.movie_id) LEFT OUTER JOIN user ON user.id = users_movies.user_id WHERE movie.title LIKE '%" + movie_name + "%';");
           command = new MySqlCommand(query, connection);
           MySqlDataAdapter adapter = new MySqlDataAdapter(command);


           DataTable data = new DataTable();
           adapter.Fill(data);
           dataGridView1.DataSource = data;

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form14 review = new Form14(label6.Text);
            review.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Movie_Database
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
            DBConnect db = new DBConnect();
            db.OpenConnection();
            MySqlDataReader myReader;

            MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM director",db.getConnection());


            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd/MM/yyyy";

            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.CustomFormat = "dd/MM/yyyy";

            myReader = SelectCommand.ExecuteReader();
            int count = 0;
            while (myReader.Read())
            {
                comboBox1.Items.Add(myReader.GetString("id"));
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.InitialDirectory = "C:\\";
            open.Filter = "Image Files (*.jpg)|*.jpg|All Files(*.*)|*.*";
            open.FilterIndex = 1;
            if (open.ShowDialog() == System.Windows.Forms.DialogResult.OK) { 
                if(open.CheckFileExists){
                    string pathname = System.IO.Path.GetFileName(open.FileName);
                    label14.Text = pathname;
                    System.IO.File.Copy(open.FileName, @"D:/C++ Programs(While Learning)/Movie Database/images/movies/"+pathname);
                }
            }
        }

        private void label14_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string title = textBox1.Text;
            string year = textBox5.Text;
            string genre = textBox4.Text;
            string image = label14.Text;
            string director_id = comboBox1.Text;
            string about = richTextBox1.Text;


            DBConnect db = new DBConnect();
            if (db.OpenConnection())
            {
                MySqlConnection connection = db.getConnection();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "INSERT INTO `movie`(`title`, `genre`, `year`, `director_id`, `image`, `about`) VALUES ('" + title + "','" + genre + "', '" + year + "','"+ director_id  +"','"+image+"','"+about+"' );";
                command.ExecuteNonQuery();
                MessageBox.Show("Movie Inserted Succesfully");
            }
            else
            {
                MessageBox.Show("NOT Connected");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DBConnect db = new DBConnect();
            if (db.OpenConnection())
            {

                string name = textBox2.Text;
                string gender = comboBox2.Text;
                string dob = dateTimePicker1.Text;
                string about = richTextBox2.Text;
                string image = label15.Text;
                MySqlConnection connection = db.getConnection();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "INSERT INTO `director`( `name`, `gender`, `dob`, `about`, `image`) VALUES ('" + name + "','" + gender + "', '" + dob + "','" + about + "','" + image + "');";
                command.ExecuteNonQuery();
                MessageBox.Show("Director Inserted Succesfully");
            }
            else
            {
                MessageBox.Show("NOT Connected");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.InitialDirectory = "C:\\";
            open.Filter = "Image Files (*.jpg)|*.jpg|All Files(*.*)|*.*";
            open.FilterIndex = 1;
            if (open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (open.CheckFileExists)
                {
                    string pathname = System.IO.Path.GetFileName(open.FileName);
                    label15.Text = pathname;
                    System.IO.File.Copy(open.FileName, @"D:/C++ Programs(While Learning)/Movie Database/images/directors/" + pathname);
                }
            }
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.InitialDirectory = "C:\\";
            open.Filter = "Image Files (*.jpg)|*.jpg|All Files(*.*)|*.*";
            open.FilterIndex = 1;
            if (open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if (open.CheckFileExists)
                {
                    string pathname = System.IO.Path.GetFileName(open.FileName);
                    label21.Text = pathname;
                    System.IO.File.Copy(open.FileName, @"D:/C++ Programs(While Learning)/Movie Database/images/actors/" + pathname);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DBConnect db = new DBConnect();
            if (db.OpenConnection())
            {

                string name = textBox3.Text;
                string gender = comboBox3.Text;
                string dob = dateTimePicker2.Text;
                string about = richTextBox3.Text;
                string image = label21.Text;
                MySqlConnection connection = db.getConnection();
                MySqlCommand command = connection.CreateCommand();
                command.CommandText = "INSERT INTO `actor`(`name`, `gender`, `dob`, `about`, `image`) VALUES ('" + name + "','" + gender + "', '" + dob + "','" + about + "','" + image + "');";
                command.ExecuteNonQuery();
                MessageBox.Show("Actor Inserted Succesfully");
            }
            else
            {
                MessageBox.Show("NOT Connected");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

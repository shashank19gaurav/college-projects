﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Database
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;
            string query = "SELECT distinct(movie.id) as No, movie.title as Title, director.name Director, movie.year as Year FROM (movie INNER JOIN director ON movie.director_id = director.id) LEFT OUTER JOIN (actors_movies INNER join actor on actors_movies.actor_id = actor.id) on movie.id = actors_movies.movie_id ";
            if(textBox1.Text!=""){
                query += "WHERE ";
                query += "Title LIKE '%" + textBox1.Text + "%' ";
                count++;
            }
            if (textBox2.Text != "") {
                if (count != 0)
                {
                    query += "AND ";
                }
                else {

                    query += "WHERE ";

                }
                query += "year =  " + textBox2.Text + " ";
                count++;
            }
            if (textBox3.Text != "") {
                if (count != 0)
                {
                    query += "AND ";
                }
                else
                {

                    query += "WHERE ";

                }
                query += " director.name LIKE '%" + textBox3.Text + "%' ";
                count++;
            }
            if (textBox4.Text != "") {
                if (count != 0)
                {
                    query += "AND ";
                }
                else
                {

                    query += "WHERE ";

                }
                query += " actor.name LIKE '%" + textBox4.Text + "%' ";
                count++;            
            }
            query += ";";

            Form6 movies = new Form6(query);
            movies.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

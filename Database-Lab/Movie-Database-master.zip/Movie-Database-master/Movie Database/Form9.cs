﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Movie_Database
{
    public partial class Form9 : Form
    {
        public Form9(string director_name)
        {
            InitializeComponent();
            string director_id ="";
            DBConnect db = new DBConnect();
            db.OpenConnection();

            MySqlConnection connection = db.getConnection();
            MySqlCommand command = connection.CreateCommand();
            string query = "SELECT * FROM director WHERE name LIKE '%" + director_name + "%';";
            command.CommandText = query;
            // MessageBox.Show(query);
            //command.ExecuteReader();
            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                    label1.Text = reader.GetString(reader.GetOrdinal("gender"));
                    richTextBox1.Text = reader.GetString(reader.GetOrdinal("about"));
                    label4.Text = reader.GetString(reader.GetOrdinal("name"));
                    label7.Text = reader.GetString(reader.GetOrdinal("dob"));
                    director_id = reader.GetString(reader.GetOrdinal("id"));

                    string imagelink = "D:/C++ Programs(While Learning)/Movie Database/images/directors/" + reader.GetString(reader.GetOrdinal("image"));

                    pictureBox1.Image = Image.FromFile(imagelink);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox1.Size = new Size(150, 150);

                }
            }
            query = String.Format(" SELECT  distinct(movie.title) as Title FROM (movie INNER JOIN director ON movie.director_id = director.id) LEFT OUTER JOIN (actors_movies INNER join actor on actors_movies.actor_id = actor.id) on movie.id = actors_movies.movie_id WHERE director.id = " + director_id + ";");
            command = new MySqlCommand(query, connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);


            DataTable data = new DataTable();
            adapter.Fill(data);
            dataGridView1.DataSource = data;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string value = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            //MessageBox.Show(value);

            Form7 movie_profile = new Form7(value);
            movie_profile.Show();
            this.Hide();
        }
    }
}

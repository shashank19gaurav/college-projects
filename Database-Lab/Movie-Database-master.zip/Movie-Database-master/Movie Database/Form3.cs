﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using MySql.Data.MySqlClient;

namespace Movie_Database
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            DBConnect db = new DBConnect();
            if (db.OpenConnection())
            {
                string query = String.Format("SELECT title FROM movie LIMIT 10");

                MySqlConnection connection = db.getConnection();
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);


                DataTable data = new DataTable();
                adapter.Fill(data);
                dataGridView1.DataSource = data;
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            string value = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            //MessageBox.Show(value);

            Form7 movie_profile = new Form7(value);
            movie_profile.Show();
            this.Hide();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form10 actor_search = new Form10();
            actor_search.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 details = new Form4();
            details.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 movie_search = new Form5();
            movie_search.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form11 director_search = new Form11();
            director_search.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Movie_Database
{
    public partial class Form6 : Form
    {
        public Form6(string query)
        {

            //MessageBox.Show(query);
            
            InitializeComponent();
            DBConnect db = new DBConnect();
            MySqlConnection connection = db.getConnection();
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);

            
            DataTable data = new DataTable();
            adapter.Fill(data);
            dataGridView1.DataSource = data;
             

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string value = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            //MessageBox.Show(value);

            Form7 movie_profile = new Form7(value);
            movie_profile.Show();
            this.Hide();
        }
    }
}
